export const BaseURL = "https://story-api.dicoding.dev/v1"


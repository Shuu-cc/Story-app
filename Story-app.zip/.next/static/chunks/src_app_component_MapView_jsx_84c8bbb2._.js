(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b6fa4529._.js",
  "static/chunks/src_app_component_MapView_jsx_e2a76d8f._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_88e19fd3.css"
],
    source: "dynamic"
});

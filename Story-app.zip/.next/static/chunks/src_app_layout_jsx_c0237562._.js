(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__36bd7e9c._.css",
  "static/chunks/_6c90e364._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_component_MapView_jsx_16be839b._.js",
  "static/chunks/_346a4dec._.js"
],
    source: "dynamic"
});
